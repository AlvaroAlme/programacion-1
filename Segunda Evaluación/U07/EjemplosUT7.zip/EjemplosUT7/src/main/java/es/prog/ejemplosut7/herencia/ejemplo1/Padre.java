/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.herencia.ejemplo1;

public class Padre {
    String nombre;
    
    public Padre(String nombre) {
        this.nombre = nombre;
        System.out.print(nombre);
    }
    
}
