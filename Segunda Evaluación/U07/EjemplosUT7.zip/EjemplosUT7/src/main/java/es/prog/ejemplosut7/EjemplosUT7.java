/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package es.prog.ejemplosut7;

import es.prog.ejemplosut7.herencia.ejemplo1.Hija;
import es.prog.ejemplosut7.herencia.ejemplo2.Hija2;
import es.prog.ejemplosut7.herencia.ejemplo3.Estudiante;
import es.prog.ejemplosut7.herencia.ejemplo3.Persona;
import es.prog.ejemplosut7.herencia.ejemplo3.Profesor;
import es.prog.ejemplosut7.interfaces.Color;
import es.prog.ejemplosut7.interfaces.Cuadrado;
import es.prog.ejemplosut7.interfaces.Forma;
import es.prog.ejemplosut7.polimorfismo.Animal;
import es.prog.ejemplosut7.polimorfismo.Perro;
import es.prog.ejemplosut7.polimorfismo.Pitbull;

/**
 *
 * @author educarm
 */
public class EjemplosUT7 {

    public static void main(String[] args) {
        //Herencia, ejemplo 1
        Hija hija = new Hija(12, "Manuel");

        //Herencia, ejemplo 2
        Hija2 hija2 = new Hija2(15, "Federico", "Alicia");
        hija2.mostrarInfo();
        
        //Herencia, ejemplo 3
        Estudiante e = new Estudiante("Luís García", 20);
        Persona p = new Persona("Marta Gómez", 20);
        System.out.println(p.getNombre());
        System.out.println(e.getNombre() + " : " + e.getCreditos() + " créditos");
        
        //Ejemplo sobreescritura de métodos
        Persona p2 = new Persona("Luís García", 20);
        Estudiante e2 = new Estudiante("Luís García", 20);
        Profesor pr = new Profesor("Luís García", 20, "Informática");
        System.out.println(p2);
        System.out.println(p2.toString());
        System.out.println(e2);
        System.out.println(e2.toString());
        System.out.println(pr);
        System.out.println(pr.toString());

        //Ejemplo polimorfismo
        Animal[] animales = new Animal[]{new Animal(), new Perro(), new Pitbull()};
        for (Animal a : animales) {
            a.hacerRuido();
        }
        
        //Ejemplo interfaces
        Cuadrado cuadrado = new Cuadrado(2.5f, "verde");
        Forma forma = cuadrado;
        System.out.println("Área del cuadrado=" + forma.area());
        forma.dibujar();
        
        Color color = cuadrado;
        System.out.println("Color del cuadrado=" + color.color());
    }
}
