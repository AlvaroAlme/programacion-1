/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.clasesabstractas;

public class Triangulo extends Figura2D {

    private Punto2D p1, p2, p3;

    public Triangulo(Punto2D p1, Punto2D p2, Punto2D p3) {
        super(3);
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    @Override
    public double area() {
        double a = Punto2D.distancia(p1, p2);
        double b = Punto2D.distancia(p2, p3);
        double c = Punto2D.distancia(p3, p1);
        double s = (a + b + c) / 2;
        return (Math.sqrt(s * (s - a) * (s - b) * (s - c)));
    }
}
