/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.herencia.ejemplo2;

public class Padre2 {
    String nombre;

    public Padre2(String nombre) {
        this.nombre = nombre;
        System.out.print(nombre);
    }

    public void mostrarInfo() {
        System.out.println("Padre: " + nombre);
    }
}
