/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.herencia.ejemplo3;

/**
 *
 * @author educarm
 */
public class Profesor extends Persona {

    String departamento;

    public Profesor(String nombre, int edad, String departamento) {
        super(nombre, edad);
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return super.toString() + " Dep:" + departamento;
    }
}
