/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.herencia.ejemplo2;

public class Hija2 extends Padre2 {
    String nombre;
    int edad;

    public Hija2(int edad, String padre, String hija) {
        super(padre);
        this.nombre = hija;
        this.edad = edad;
        System.out.println(" tiene una hija de " + edad + " años");
    }

    public void mostrarInfo() {
        System.out.println("Hija: " + nombre + ", edad: " + edad + " años");
        super.mostrarInfo();
    }
}
