/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.interfaces;

public class Rectangulo implements Forma {
    private double ancho;
    private double largo;

    public Rectangulo(double ancho, double largo) {
        this.ancho = ancho;
        this.largo = largo;
    }

    @Override
    public void dibujar() {
        System.out.println("Rectángulo dibujado");
    }

    @Override
    public double area() {
        return ancho * largo;
    }
}
