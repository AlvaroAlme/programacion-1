/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.interfaces;

public class Cuadrado implements Forma, Color {

    private double lado;
    private String color;

    public Cuadrado(double lado, String color) {
        this.lado = lado;
        this.color = color;
    }
    
     @Override
    public void dibujar() {
        System.out.println("Cuadrado dibujado");
    }

    @Override
    public double area() {
        return lado * lado;
    }

    @Override
    public String color() {
        return color;
    }
}
