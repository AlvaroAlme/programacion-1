/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.polimorfismo;

public class Animal {

    public void hacerRuido() {
        System.out.println("El animal hace un ruido");
    }
}
