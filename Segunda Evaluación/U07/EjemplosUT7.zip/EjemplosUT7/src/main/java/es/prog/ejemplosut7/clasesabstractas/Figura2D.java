/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.prog.ejemplosut7.clasesabstractas;

public abstract class Figura2D {

    private int numeroLados;

    public Figura2D(int numeroLados) {
        this.numeroLados = numeroLados;
    }

    public abstract double area();
}
