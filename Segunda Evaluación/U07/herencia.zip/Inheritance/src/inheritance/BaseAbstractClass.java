package inheritance;

/**
 * Representa una clase base (o superclase) abstracta. 
 * 
 * Una superclase se utiliza para representar los atributos y métodos comunes 
 * a un conjunto de clases derivadas. 
 * 
 * No existe un modificador específico para calificar a una superclase.
 * Detectaremos que se trata de una superclase porque en el proyecto hay otras
 * clases que derivan de esta.
 * 
 * En las clases derivadas (o subclases) únicamente se definen los
 * atributos y métodos específicos de la subclase, y se heredan los que están
 * definidos en la superclase.
 * 
 * Además, esta clase está decorada con el modificador abstract, con lo que 
 * estamos indicando lo siguiente:
 * 
 *      -   Que esta clase representa una entidad abstracta (un vehículo 
 *          abstracto, un documento abstracto, un producto abstracto, etc.).
 *          Esa representación abstracta debe ser concretada en las clases 
 *          derivadas añadiéndoles la información o los métodos
 *          necesarios para concretar la representación (y así tendremos un
 *          tipo Coche o un tipo Furgoneta, o bien un tipo Factura o un tipo 
 *          Albarán, etc.).
 * 
 *      -   Que la clase no puede ser instanciada directamente, aunque sí se
 *          podrán instanciar las clases derivadas, siempre que no se hayan
 *          declarado, a su vez, como abstractas.
 * 
 *      -   Que la clase puede declarar métodos abstractos, es decir, que puede
 *          declarar la firma de un método cuyo cuerpo no está implementado. 
 *          Esto resulta útil cuando todas las clases derivadas tienen un 
 *          método, pero la implementación de dicho método varía en cada clase.
 * 
 *          Cualquier clase derivada de esta, debe dotar de implementación a 
 *          esos métodos abstractos, manteniendo la misma firma y la misma o 
 *          mayor visibilidad.
 * 
 * Por último, esta clase implementa una interfaz IBaseContract1. 
 * Esto quiere decir que se compromete a definir los métodos públicos 
 * especificados en esa interfaz. 
 * 
 * Al implementar una interfaz, se está expresando que se debe interactuar con 
 * esta clase a través de los métodos especificados en la interfaz (siempre que
 * se acceda al objeto a través de una referencia IBaseContract1).
 */
public abstract class BaseAbstractClass implements IBaseContract1
    {
    /**
     * Campo de respaldo del getter getInterfaceAttribute1
     */
    private final int attribute1;
    
    /**
     * Devuelve el valor del campo de respaldo asociado. 
     * 
     * Este getter está decorado con la etiqueta @Override porque se 
     * corresponde con el getter definido en la interfaz IBaseContract1
     * @return El valor del campo de respaldo asociado.
     */
    @Override
    public int getInterfaceAttribute1() { return this.attribute1; }
    
    /**
     * Crea una nueva instancia de la clase.
	 * 
	 * Observa que, al ser una clase abstracta, no se puede invocar al 
	 * constructor desde fuera de esta clase. El constructor sólo puede ser
	 * invocado por las clases derivadas, por lo que puede hacerse protected.
	 * 
     * @param value parámetro que se mapeará con el valor del atributo 
     *              attribute1
     */
    protected BaseAbstractClass(int value)
        {
        this.attribute1 = value;
        }
    
    /**
     * Este método tiene visibilidad protegida. En Java esto quiere decir:
     * 
     *		-	Es visible desde cualquier tipo observador externo presente en 
	 *			en el mismo paquete (igual que si fuera public, pero limitado al
	 *			paquete)
     * 
     *		-	Es visible para tipos derivados, incluso si están en un paquete 
	 *			diferente
	 * 
	 * Además, este método está declarado como abstracto. Esto quiere decir:
	 * 
	 *		-	Que el método no tiene implementación en esta clase. Observa que
	 *			el método no tiene cuerpo (no hay llaves {}), sino que la firma
	 *			termina en ;
	 * 
	 *		-	Que las clases derivadas deben necesariamente dotar de una 
	 *			implementación concreta a este método (o bien, redefinirlo como
	 *			abstracto).
     */
    protected abstract void test1();
    
	/**
	 * Este es un método público convencional. Observa que no está incluido
	 * en la interfaz IBaseContract1 que implementa esta clase. Por esta razón,
	 * al acceder a una instancia de esta clase mediante una referencia de tipo
	 * IBaseContract1, no podrás acceder a este miembro.
	 * 
	 * No obstante, el método es invocable a través de una referencia de tipo
	 * BaseAbstractClass (o un tipo derivado de éste).
	 */
    public void test2() {}
	}
