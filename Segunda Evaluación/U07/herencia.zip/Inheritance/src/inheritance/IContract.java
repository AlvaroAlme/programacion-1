package inheritance;

/**
 * Representa un contrato de implementación de miembros públicos.
 * 
 * En este caso, la interfaz presenta herencia múltiple (hereda los miembros
 * de las interfaces IBaseContract1 e IBaseContract2) y, además, añade un
 * tercer miembro declarado en esta misma interfaz.
 */
public interface IContract extends IBaseContract1, IBaseContract2
    {
	// Los miembros de las interfaces IBaseContract1 e IBaseContract2 están
	// presentes de forma implícita en esta interfaz. Es como si estuvieran 
	// definidos aquí:
	//
	//  int getInterfaceAttribute1();
	//	int getInterfaceAttribute2();
	
    int getInterfaceAttribute3();
    }
