package inheritance;

/**
 * Representa una clase base (o superclase). 
 * 
 * Una superclase se utiliza para representar los atributos y métodos comunes 
 * a un conjunto de clases derivadas. 
 * 
 * No existe un modificador específico para calificar a una superclase.
 * Detectaremos que se trata de una superclase porque en el proyecto hay otras
 * clases que derivan de esta.
 * 
 * En las clases derivadas (o subclases) únicamente se definen los
 * atributos y métodos específicos de la subclase, y se heredan los que están
 * definidos en la superclase.
 */
public class BaseClass
    {
	/**
     * Campo de respaldo del getter getAttribute1
     */
    private final int attribute1;
	
	 /**
     * Devuelve el valor del campo de respaldo asociado. 
     */
    public int getAttribute1() { return this.attribute1; }
    
	/**
     * Crea una nueva instancia de la clase
     * @param value parámetro que se mapeará con el valor del atributo 
     *              attribute1
     */
    public BaseClass(int value)
        {
        this.attribute1 = value;
        }
    
     /**
     * Este método tiene visibilidad protegida. En Java esto quiere decir:
     * 
     *		-	Es visible desde cualquier tipo observador externo presente en 
	 *			en el mismo paquete (igual que si fuera public, pero limitado al
	 *			paquete)
     * 
     *		-	Es visible para tipos derivados, incluso si están en un paquete 
	 *			diferente
	 */     
    protected void test1() { }
	
	/**
	 * Este es un método público convencional.
	 * 
	 * @return Una cadena que identifica al método.
	 */ 
	public String test2() { return "Método de la clase BaseClass"; }
    }
