package inheritance;

/**
 * Hereda de la clase BaseClass y, además, implementa la interfaz IContract
 * @author Curro
 */
public class DerivedClass1 extends BaseClass implements IContract
    {
	/*
	 * Todos los miembros que se encuentran definidos en la clase base están
	 * también presentes en esta clase. Si escribes "this." , con ayuda del
	 * completador de código, verás que tienes acceso a los miembros de esta 
	 * clase y también a los miembros que no sean privados de la clase base.
	 * 
	 * También se puede utilizar la referencia "super." para explicitar que se
	 * quiere acceder a uno de los miembros de la clase base (es indiferente
	 * usar super o this, pero super aporta una carga semántica que indica la 
	 * intención de querer acceder a un miembro de la clase base).
	 */
	
	/**
	 * Crea una nueva instancia de la clase.
	 * 
	 * Observa que es *obligatorio* que la primera sentencia del constructor
	 * sea la llamada al constructor de la clase base. La única excepción a
	 * esta regla se da cuando la clase base tiene un constructor sin 
	 * parámetros.
	 * 
	 * @param value un valor entero que se pasa al constructor de la clase base.
	 */
    public DerivedClass1(int value)
        {
		// super es una referencia a la clase base. En este caso está indicando
		// que llama al constructor de la clase base y le pasa como parámetro
		// value
        super(value);
		
		// si fuera necesario, aquí podría añadirse código para realizar otras
		// inicializaciones en la clase (siempre después de la llamada a super).
        }

	/**
	 * Campo de respaldo del getter getInterfaceAttribute1();
	 */
	private int interfaceAttribute1;
	
    /**
	 * Como esta clase implementa la interfaz IContract, está obligada a definir
	 * todos los miembros que se especifican en esa interfaz. 
	 * 
	 * Los miembros implementados se decoran con la etiqueta @Override.
	 * 
	 * @return El valor del atributo interfaceAttribute1.
	 */
	@Override
    public int getInterfaceAttribute1()
        {
        return this.interfaceAttribute1;
		// También sería posible devolver el valor de un miembro presente en la 
		// clase base. Por ejemplo, podríamos haber escrito:
		// return super.getAttribute1();
        }

	@Override
    public int getInterfaceAttribute2()
        {
        //throw new UnsupportedOperationException("Not supported yet."); 
		return 2;
        }
	
    @Override
    public int getInterfaceAttribute3()
        {
        // throw new UnsupportedOperationException("Not supported yet."); 
		return 3;
        }   
	
	/**
	 * Reemplaza al método correspondiente de la clase base.
	 * 
	 * Es posible sustituir un método de la clase base por otro que tiene la
	 * misma firma pero distinta implementación. 
	 * 
	 * Si se llama al método test2 sobre una referencia de tipo DerivedClass1,
	 * se ejecutará este método, en vez de ejecutar el método de la clase base.
	 * 
	 * Es habitual tener que invocar al método homónimo de la clase base, para 
	 * lo que puede utilizarse la referencia super.
	 * 
	 * @return Una cadena que identifica al método
	 */
	@Override
	public String test2() 
		{ 
		// se podría invocar al método de la clase base con: super.test2();
		return "método de la clase DerivedClass1"; 
		}
    }
