package inheritance;

/**
 * Representa un contrato de implementación de miembros públicos.
 * 
 * Cualquier clase que implemente esta interfaz, debe incluir los métodos que
 * se incluyen en esta interfaz.
 * 
 * La implementación del método puede variar en las distintas clases 
 * implementadoras, pero siempre deben tener la misma firma.
 */
public interface IBaseContract1
    {
    int getInterfaceAttribute1();
    }
