package inheritance;

/**
 * Hereda de la clase BaseAbstractClass
 */
public class DerivedClass2 extends BaseAbstractClass
    {
	/*
	 * Todos los miembros que se encuentran definidos en la clase base están
	 * también presentes en esta clase. Si escribes "this." , con ayuda del
	 * completador de código, verás que tienes acceso a los miembros de esta 
	 * clase y también a los miembros que no sean privados de la clase base.
	 * 
	 * También se puede utilizar la referencia "super." para explicitar que se
	 * quiere acceder a uno de los miembros de la clase base (es indiferente
	 * usar super o this, pero super aporta una carga semántica que indica la 
	 * intención de querer acceder a un miembro de la clase base).
	 */
	
	/**
	 * Crea una nueva instancia de la clase.
	 * 
	 * Observa que es *obligatorio* que la primera sentencia del constructor
	 * sea la llamada al constructor de la clase base. La única excepción a
	 * esta regla se da cuando la clase base tiene un constructor sin 
	 * parámetros.
	 * 
	 * @param value un valor entero que se pasa al constructor de la clase base.
	 */
    public DerivedClass2(int value)
        {
        super(value);
        }

	/**
	 * Dota de una implementación al método abstracto de la clase base.
	 * 
	 * La implementación de un método abstracto debe ir decorada con la etiqueta
	 * @Override.
	 * 
	 * Se debe mantener exactamente la misma firma que en el método abstracto de
	 * la clase base, pero se puede ampliar la visibilidad (se puede hacer 
	 * public).
	 */
    @Override
    protected void test1()
        {
        // throw new UnsupportedOperationException("Not supported yet."); 
        }
    }
