package inheritance;

public interface IBaseContract2
    {
    int getInterfaceAttribute2();
    }
