package inheritance;

public class Program
	{
        /**
         * Este método es polimórfico puesto que puede recibir como parámetro
         * cualquier objeto (del tipo que sea), siempre que implemente la 
         * interfaz IContract.
         * 
         * En general, suele ser una buena práctica utilizar como tipo de los
         * parámetros el tipo menos derivado de una jerarquía de herencia, 
         * siempre que sea posible y tenga sentido en el contexto del programa
         * 
         * @param obj   parámetro de cualquier tipo que implemente al interfaz 
         *              IContract.
         */
        private static void method(IContract obj)
            {
            
            }
        
	public static void main(String[] args)
		{
		// La clase base BaseClass no es abstracta y puede ser instanciada
		// normalmente.
		// A través de una referencia de tipo BaseClass se accede a los miembros
		// declarados en esa clase:
		BaseClass b1 = new BaseClass(25);
		b1.getAttribute1();
		b1.test1();
		b1.test2();
		
		// La clase DerivedClass1 hereda de BaseClass e implementa la interfaz
		// IContract. 
		// A través de una referencia de tipo DerivedClass puede accederse a los 
		// miembros de esta clase y también a los miembros de la clase base que 
		// no son privados.
		// Además, es posible acceder a los miembros definidos en la interfaz 
		// que implementa:
		DerivedClass1 d1 = new DerivedClass1(25);
		d1.getAttribute1();
		d1.test1();
		d1.test2(); // ejecuta el método de DerivedClass1, no el de BaseClass
		d1.getInterfaceAttribute1();
		d1.getInterfaceAttribute2();
		d1.getInterfaceAttribute3();
		
		// Es posible realizar una declaración polimórfica contravariante
		// como la siguiente. Se instancia un objeto DerivedClass1, pero se
		// utiliza una referencia de tipo BaseClass para apuntar a ese objeto.
		// Como la referencia utilizada es de tipo BaseClass, sólo se puede
		// acceder a los miembros de la clase BaseClass a través de esa 
		// referencia:
		BaseClass d2 = new DerivedClass1(25);
		d2.getAttribute1();
		d2.test1();
		d2.test2(); // OJO: Ejecuta el método de DerivedClass1, incluso si la 
					// referencia utilizada es de tipo BaseClass
		
		// Si se convierte la referencia a un tipo DerivedClass1, volvemos a 
		// obtener acceso a los miembros del tipo DerivedClass1
		((DerivedClass1)d2).getInterfaceAttribute1();
		
		
		// También es posible realizar una declaración contravariante utilizando
		// la interfaz implementada por la clase. Al igual que en el caso 
		// anterior, la referencia utilizada sólo permite acceder a los miembros
		// declarados en la interfaz:
		IContract d3 = new DerivedClass1(25);
		d3.getInterfaceAttribute1();
		d3.getInterfaceAttribute2();
		d3.getInterfaceAttribute3();
		
		// --------------------------------------------------
		
		// Error: no se puede instanciar una clase abstracta
		// BaseAbstractClass error = new BaseAbstractClass(25);
		
		// DerivedClass2 extiende la clase BaseAbstractClass 
		DerivedClass2 d4 = new DerivedClass2(25);
		d4.test1();
		d4.test2();
		d4.getInterfaceAttribute1();
                
                // --------------------------------------------------
                
                // Por el principio de sustitución de Liskov, podemos reemplazar
                // cualquier referencia a objeto de un determinado tipo por una
                // referencia a objeto de un tipo más derivado. Esto proporciona
                // un comportamiento polimórfico covariante:
                method(d1);
                method(d3);
                
                // Error: esta llamada no es posible porque la referencia d2, 
                //        que es de tipo BaseClass, no es compatible con 
                //        IContract, ya que BaseClass no implementa IContract.
                //method(d2);
                
		}
	}
